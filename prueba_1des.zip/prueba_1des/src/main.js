// 1. AGARRAR LOS CABLES
// Aquí le decimos a JavaScript cuáles son las piezas que vamos a usar de nuestra pared (HTML)
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const loginBtn = document.getElementById('login-btn');
const errorMessage = document.getElementById('error-message');

// Nuestras dos grandes cajas (habitaciones)
const loginView = document.getElementById('login-view');
const appView = document.getElementById('app-view');

// 2. ESCUCHAR AL BOTÓN "ENTRAR"
// Le decimos al botón que preste atención cuando alguien le haga "click"
loginBtn.addEventListener('click', async () => {
    
    // Leemos lo que el trabajador escribió en las cajitas
    const correoEscrito = emailInput.value;
    const contrasenaEscrita = passwordInput.value;

    try {
        // 3. MANDAR AL MENSAJERO AL ARCHIVERO (Fetch API)
        // Pedimos la lista de usuarios al bibliotecario (json-server)
        const respuesta = await fetch('http://localhost:3000/users');
        const listaDeUsuarios = await respuesta.json();

        // 4. BUSCAR SI LA LLAVE COINCIDE
        // Buscamos en la lista si alguien tiene exactamente ese correo y esa contraseña
        const trabajadorEncontrado = listaDeUsuarios.find(
            usuario => usuario.email === correoEscrito && usuario.password === contrasenaEscrita
        );

        if (trabajadorEncontrado) {
            // ¡SI EXISTE! 
            
            // Le damos un "gafete" mágico para que la oficina lo recuerde (localStorage)
            localStorage.setItem('usuarioLogueado', JSON.stringify(trabajadorEncontrado));
            
            // Apagamos la luz de la recepción y prendemos la de la oficina
            loginView.style.display = 'none';
            appView.style.display = 'flex';
            mostrarProyectos();
            
            // Escondemos el mensaje de error por si estaba prendido
            errorMessage.style.display = 'none';
            
        } else {
            // SI SE EQUIVOCÓ, prendemos la alarma roja (el mensaje de error)
            errorMessage.style.display = 'block';
        }

    } catch (error) {
        console.error("El bibliotecario no responde", error);
    }
});


// 5. EL GUARDIA VIGILANTE (Recordar al trabajador)
function revisarGafete() {
    // Le decimos al guardia que busque el gafete mágico en el bolsillo
    const gafeteGuardado = localStorage.getItem('usuarioLogueado');
    
    if (gafeteGuardado) {
        // ¡Si encuentra el gafete! Lo deja pasar a la oficina sin pedir clave
        loginView.style.display = 'none';
        appView.style.display = 'flex';
    }
    mostrarProyectos();
}

// Llamamos al guardia para que haga esta revisión apenas la página cargue
revisarGafete();

// 6. LA PUERTA DE SALIDA (Logout)
// Agarramos el cable del botón de salir que está en tu HTML
const logoutBtn = document.getElementById('logout-btn');

logoutBtn.addEventListener('click', () => {
    // El guardia le quita el gafete (lo borramos del bolsillo)
    localStorage.removeItem('usuarioLogueado');
    
    // Lo sacamos de la oficina y prendemos la luz de la recepción
    appView.style.display = 'none';
    loginView.style.display = 'block';
    
    // Limpiamos las cajitas de texto para que queden vacías para el siguiente
    emailInput.value = '';
    passwordInput.value = '';
});

// 7. AGARRAR LA MESA DE TRABAJO DE LA PARED
const projectsContainer = document.getElementById('projects-container');

// 8. TRAER LAS CARPETAS A LA MESA (Proyectos)
async function mostrarProyectos() {
    try {
        // El mensajero va al archivero por la caja de proyectos
        const respuesta = await fetch('http://localhost:3000/projects');
        const listaProyectos = await respuesta.json();
        
        // Leemos el gafete del bolsillo para saber quién está adentro
        // Usamos JSON.parse para convertir ese texto de nuevo en nuestro trabajador
        // Leemos el gafete del bolsillo para saber quién está adentro
        const usuarioLogueado = JSON.parse(localStorage.getItem('usuarioLogueado'));

        // Agarramos la máquina de la pared
        const managerTools = document.getElementById('manager-tools');

        // ¡AQUÍ ESTÁ EL CAMBIO! Usamos el nombre correcto del gafete
        if (usuarioLogueado.role === 'manager') {
            managerTools.style.display = 'block'; // Le quita la manta invisible
        } else {
            managerTools.style.display = 'none'; // La esconde del ayudante
        }

        // Limpiamos la mesa por si había carpetas viejas
        projectsContainer.innerHTML = '';

        // Revisamos cada proyecto uno por uno
        listaProyectos.forEach(proyecto => {
            
            // LA REGLA SÚPER IMPORTANTE: 
            // ¿Es manager? O, ¿su número (id) es igual al asignado en el proyecto (assignedTo)?
            if (usuarioLogueado.role === 'manager' || proyecto.assignedTo === usuarioLogueado.id) {
                
                // Creamos una tarjetita de cartón
                const tarjetita = document.createElement('div');
                tarjetita.className = 'proyecto-card'; 
                tarjetita.innerHTML = `
                    <h4>${proyecto.name}</h4>
                    <p>${proyecto.description}</p>
                    <p><strong>Estado:</strong> <span>${proyecto.status}</span></p>
                `;
                
                // Ponemos la tarjetita en la mesa
                projectsContainer.appendChild(tarjetita);
            }
        });

    } catch (error) {
        console.error("El archivero no responde al buscar proyectos", error);
    }
}