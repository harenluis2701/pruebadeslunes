import { router } from '../router/router.js';
import { loginUser } from './auth.js';

// Vincula el evento de login cuando el formulario aparezca en el DOM
window.initLoginLogic = () => {
    const form = document.getElementById('login-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('auth-error');

        const result = await loginUser(email, password);
        if (result.success) {
            window.location.hash = '#dashboard'; // Al cambiar el hash, el router hace el resto [cite: 106, 114]
        } else {
            errorDiv.innerText = result.message; // [cite: 32, 33]
        }
    });
};

// Importar dinámicamente las funciones del dashboard para que el router las use
import { initDashboardLogic } from './dashboard.js';
window.initDashboardLogic = initDashboardLogic;