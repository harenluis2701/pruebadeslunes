const API_URL = "http://localhost:3000/users";

export async function loginUser(email, password) {
    try {
        // Buscamos el usuario por su correo electrónico [cite: 28, 30]
        const response = await fetch(`${API_URL}?email=${email}`);
        if (!response.ok) throw new Error("Error en el servidor"); // [cite: 32]
        
        const users = await response.json();

        // Validamos la existencia y coincidencia de contraseña [cite: 29, 30]
        if (users.length > 0 && users[0].password === password) {
            const user = users[0];
            // Guardamos datos de sesión sin la contraseña por seguridad
            const sessionData = { id: user.id, name: user.name, role: user.role };
            localStorage.setItem('user_session', JSON.stringify(sessionData)); // [cite: 36]
            return { success: true };
        } else {
            return { success: false, message: "Credenciales incorrectas" }; // [cite: 32]
        }
    } catch (error) {
        return { success: false, message: "No se pudo conectar con el servidor" }; // [cite: 32]
    }
}