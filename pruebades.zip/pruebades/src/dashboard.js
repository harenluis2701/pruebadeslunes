const PROJECTS_URL = "http://localhost:3000/projects";

export async function initDashboardLogic(user) {
    // Mostrar datos del usuario en la interfaz
    document.getElementById('user-name').innerText = user.name;
    document.getElementById('user-role').innerText = user.role.toUpperCase();

    // Mostrar acciones exclusivas de Manager [cite: 53]
    if (user.role === 'manager') {
        document.getElementById('manager-actions').classList.remove('d-none');
    }

    const createButton = document.getElementById('btn-create-project');
    if (createButton) {
        createButton.onclick = () => createProject(user);
    }

    await loadProjects(user);
}

async function loadProjects(user) {
    try {
        // Cargar proyectos filtrados por rol [cite: 55, 62]
        let url = PROJECTS_URL;
        if (user.role === 'collaborator') {
            url = `${PROJECTS_URL}?assignedTo=${user.id}`; // Solo sus proyectos asignados [cite: 51, 62]
        }

        const res = await fetch(url); // [cite: 90, 185]
        const projects = await res.json();

        renderMetrics(projects, user.role);
        renderProjectsTable(projects, user.role);

    } catch (error) {
        console.error("Error al cargar el dashboard", error); // [cite: 186]
    }
}

async function createProject(user) {
    const name = prompt('Nombre del proyecto:');
    if (!name) return;

    const description = prompt('Descripción del proyecto:');
    if (!description) return;

    const status = prompt('Estado del proyecto:', 'In Progress');
    if (!status) return;

    const assignedToInput = prompt('ID del usuario asignado (ej. 2):', user.id);
    const assignedTo = assignedToInput ? parseInt(assignedToInput, 10) : user.id;
    if (Number.isNaN(assignedTo)) {
        alert('ID de usuario asignado inválido.');
        return;
    }

    const projectPayload = {
        name,
        description,
        status,
        assignedTo
    };

    try {
        const res = await fetch(PROJECTS_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(projectPayload)
        });

        if (!res.ok) {
            throw new Error(`Error al crear el proyecto (${res.status})`);
        }

        await loadProjects(user);
        alert('Proyecto creado correctamente.');
    } catch (error) {
        console.error('Error al crear el proyecto', error);
        alert('No se pudo crear el proyecto. Revisa la consola para más detalles.');
    }
}

// Calcular y renderizar métricas [cite: 113]
function renderMetrics(projects, role) {
    const container = document.getElementById('metrics-container');
    if (role === 'manager') {
        const total = projects.length; // [cite: 117]
        const activos = projects.filter(p => p.status !== 'Finalizado').length; // [cite: 118]
        const finalizados = projects.filter(p => p.status === 'Finalizado').length; // [cite: 125]

        container.innerHTML = `
            <div class="col-md-4"><div class="card p-3 bg-primary text-white">Total Proyectos: ${total}</div></div>
            <div class="col-md-4"><div class="card p-3 bg-warning text-dark">Activos: ${activos}</div></div>
            <div class="col-md-4"><div class="card p-3 bg-success text-white">Finalizados: ${finalizados}</div></div>
        `;
    } else {
        container.innerHTML = `
            <div class="col-md-6"><div class="card p-3 bg-info text-white">Tus Proyectos Asignados: ${projects.length}</div></div>
        `; // [cite: 128]
    }
}

// Renderizar tabla con control de permisos por rol [cite: 83, 84]
function renderProjectsTable(projects, role) {
    const listContainer = document.getElementById('projects-list');
    if (projects.length === 0) {
        listContainer.innerHTML = '<p class="text-muted">No hay proyectos para mostrar.</p>';
        return;
    }

    let rows = projects.map(p => `
        <tr>
            <td>${p.name}</td>
            <td>${p.description}</td>
            <td><span class="badge bg-secondary">${p.status}</span></td>
            <td>
                ${role === 'manager' ? `
                    <button class="btn btn-sm btn-warning" onclick="editProject(${p.id})">Editar</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteProject(${p.id})">Eliminar</button>
                ` : `
                    <button class="btn btn-sm btn-outline-primary" onclick="updateStatus(${p.id})">Cambiar Estado</button>
                `}
            </td>
        </tr>
    `).join('');

    listContainer.innerHTML = `
        <table class="table table-hover">
            <thead>
                <tr><th>Nombre</th><th>Descripción</th><th>Estado</th><th>Acciones</th></tr>
            </thead>
            <tbody>${rows}</tbody>
        </table>
    `;
}