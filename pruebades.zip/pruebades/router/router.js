// Definición de las vistas (Templates HTML básicos)
const views = {
    login: `
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card p-4 shadow-sm">
                    <h3 class="text-center mb-3">Iniciar Sesión</h3>
                    <form id="login-form">
                        <div class="mb-3">
                            <label class="form-label">Correo Electrónico</label>
                            <input type="email" id="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contraseña</label>
                            <input type="password" id="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Ingresar</button>
                    </form>
                    <div id="auth-error" class="text-danger mt-2 text-center"></div>
                </div>
            </div>
        </div>
    `,
    dashboard: `
        <div class="row">
            <div class="col-12 mb-4">
                <h2>Bienvenido, <span id="user-name"></span> (<span id="user-role"></span>)</h2>
            </div>
            <div id="metrics-container" class="row mb-4"></div>
            
            <div id="manager-actions" class="mb-3 d-none">
                <button class="btn btn-success" id="btn-create-project">Crear Nuevo Proyecto</button>
            </div>

            <div class="col-12">
                <div class="card p-3 shadow-sm">
                    <h4>Listado de Proyectos</h4>
                    <div id="projects-list" class="table-responsive mt-3"></div>
                </div>
            </div>
        </div>
    `
};

export function router() {
    const hash = window.location.hash.replace('#', '') || 'login';
    const app = document.getElementById('app');
    const navbar = document.getElementById('navbar');
    const session = JSON.parse(localStorage.getItem('user_session')); // Persistencia [cite: 34, 36]

    // 1. Protección de Rutas (Guards) [cite: 100]
    if (!session && hash !== 'login') {
        window.location.hash = '#login'; // Redirección automática [cite: 101, 106]
        return;
    }
    if (session && hash === 'login') {
        window.location.hash = '#dashboard';
        return;
    }

    // 2. Renderizado de la Vista [cite: 111]
    if (views[hash]) {
        app.innerHTML = views[hash];
    } else {
        app.innerHTML = '<h2 class="text-center">404 - Página no encontrada</h2>';
        return;
    }

    // 3. Control de visibilidad de la Navbar [cite: 107]
    if (session) {
        navbar.classList.remove('d-none');
        document.getElementById('btn-logout').onclick = () => {
            localStorage.removeItem('user_session'); // Limpieza de sesión [cite: 136]
            window.location.hash = '#login';
        };
    } else {
        navbar.classList.add('d-none');
    }

    // 4. Inicializar la lógica específica de la vista cargada
    if (hash === 'login') initLoginLogic();
    if (hash === 'dashboard') initDashboardLogic(session);
}

// Escuchar cambios en la URL [cite: 110]
window.addEventListener('hashchange', router);
window.addEventListener('DOMContentLoaded', router);